//
//  EventOrganiserCVCell.swift
//  TechGroupseTest
//
//  Created by Mihir on 30/06/20.
//  Copyright © 2020 Mihir. All rights reserved.
//

import UIKit

class EventOrganiserCVCell: UICollectionViewCell {
    @IBOutlet weak var headerLabel: UILabel!
         @IBOutlet weak var imgUser: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
