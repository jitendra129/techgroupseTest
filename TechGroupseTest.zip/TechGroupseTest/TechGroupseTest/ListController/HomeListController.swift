//
//  HomeListController.swift
//  Diagnal
//
//  Created by Mihir on 20/06/20.
//  Copyright © 2020 Mihir. All rights reserved.
//


import UIKit

protocol  HomeListControllerDelegate : class {
    //  func getUserDeails(dict : comentUser)
    
    func callNextPage(pageId:Int)
}

class HomeListController: NSObject {
    
    weak var delegate : HomeListControllerDelegate!
    var tblView : UITableView!
    
    
    var imageArray = [UIImage]()
    var typeArray = [String]()
    var indexClicked : Int = 3
    var eventData = Dictionary<String, Any>()
    // var arrItems = [Content]()
    init(delegate : HomeListControllerDelegate, tblView : UITableView) {
        self.delegate = delegate
        self.tblView = tblView
        
        super.init()
        self.setUp()
    }
    
    func setUp() {
        self.tblView.delegate = self
        self.tblView.dataSource = self
        
        self.registerNibs()
        self.tblView.reloadData()
    }
    
    //MARK:- Private Methods
    private func registerNibs() {
        
        self.tblView.register(UINib.init(nibName: kReuseIdentifierHomeCVCell, bundle: nil), forCellReuseIdentifier: kReuseIdentifierHomeCVCell)
        
        self.tblView.register(UINib.init(nibName: kReuseIdentifierDateTimeDetailTVCell, bundle: nil), forCellReuseIdentifier: kReuseIdentifierDateTimeDetailTVCell)
        self.tblView.register(UINib.init(nibName: kReuseIdentifierLocationTVCell, bundle: nil), forCellReuseIdentifier: kReuseIdentifierLocationTVCell)
        self.tblView.register(UINib.init(nibName: kReuseIdentifierEventTVCell, bundle: nil), forCellReuseIdentifier: kReuseIdentifierEventTVCell)
        
    }
    
    
    
    func refreshList(eventData:Dictionary<String, Any>) {
        //        pagingIndex = Int((imgArr.page?.pageNum)!)!
        //        if arrItems.count > 0{
        //            for img in (imgArr.page?.contentItems?.content)! {
        //                arrItems.append(img)
        //              }
        //        }else{
        //            arrItems = (imgArr.page?.contentItems?.content)!
        //        }
        self.eventData = eventData
        self.tblView.reloadData()
    }
    
    
}

//MARK:- CollectionView Delegate and DataSource.
extension HomeListController: UITableViewDelegate, UITableViewDataSource {
    func clickonTabAtIndex(index: Int) {
        print(index)
        // selectedIndex = index
        tblView.reloadData()
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        return 60
        
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let viewHeader = UITableViewHeaderFooterView(frame: CGRect(x: 0, y: 0, width: kDeviceWidth, height: 0))
        let objEVoucherHeader = Bundle.main.loadNibNamed("SectionHeaderView", owner: self, options: nil)?[0] as? SectionHeaderView ?? SectionHeaderView()
        //  objEVoucherHeader.headerLabel.text =  headerArray[section]
        
        viewHeader.addSubview(objEVoucherHeader)
        return viewHeader
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
   
        return UITableView.automaticDimension
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if self.eventData.count != 0{
            return 6
        }else{
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0{
            let cell = self.tblView.dequeueReusableCell(withIdentifier: kReuseIdentifierDateTimeDetailTVCell) as! DateTimeDetailTVCell
            cell.selectionStyle = .none
            if let eData = self.eventData["ev_start_date"] as? String{
                cell.lblDate.text = eData  + "  \(self.eventData["ev_end_date"] as! String)"
            }
            if let eData = self.eventData["ev_start_time"] as? String{
                cell.lblTime.text = eData  + "  \(self.eventData["ev_end_time"] as! String)"
            }
            if let eData = self.eventData["ev_language"] as? Int{
                cell.lblLang.text = "\(eData)"
            }else{
                print(self.eventData["ev_language"] as! String)
                //   cell.lblLang.text = "\( self.eventData["ev_language"] as! Int)"
            }
            if let eData = self.eventData["ev_gender"] as? Int{
                cell.lblMale.text = "\(eData)"
            }else{
                print(self.eventData["ev_gender"] as! String)
                // cell.lblMale.text = "\( self.eventData["ev_gender"] as! Int)"
            }
            if let eData = self.eventData["ev_start_time"] as? String{
                cell.lblYear.text = eData  + "\(self.eventData["ev_end_time"] as! String)"
            }
            
            
            return cell
        }else if indexPath.row == 1{
            let cell = self.tblView.dequeueReusableCell(withIdentifier: kReuseIdentifierLocationTVCell) as! LocationTVCell
            cell.selectionStyle = .none
            if let eData = self.eventData["ev_country"] as? String{
                cell.lblAddress.text = eData
            }
            if let eData = self.eventData["ev_region"] as? String{
                cell.lblLoc.text = eData
            }
            return cell
        }
        else if indexPath.row == 2{
            
            let cell = self.tblView.dequeueReusableCell(withIdentifier: kReuseIdentifierHomeCVCell) as! HomeTableCell
            if let eData = self.eventData["ev_description"] as? String{
                cell.lblDetail.text  = eData
            }
            
            cell.selectionStyle = .none
            return cell
        }
            
        else {
            
            let cell = self.tblView.dequeueReusableCell(withIdentifier: kReuseIdentifierEventTVCell) as! EventTVCell
            cell.selectionStyle = .none
            if indexPath.row == 3{
            if let eData = self.eventData["event_organizer"] as? Array<Dictionary<String,Any>>{
                cell.arrEventOrganiser = eData
                
            }
          cell.headerLabel.text = "View Event Organiser"
            } else if indexPath.row == 4{
            if let eData = self.eventData["event_sponser"] as? Array<Dictionary<String,Any>>{
                cell.arrEventOrganiser = eData
                
            }
                       cell.headerLabel.text = "View Event Sponcers"
              
            }
            else if indexPath.row == 5{
            if let eData = self.eventData["event_performer"] as? Array<Dictionary<String,Any>>{
                cell.arrEventOrganiser = eData
                
            }
                cell.headerLabel.text = "View Event Performer"
            }
            
            cell.configureCell()
            cell.btnPlus.addTarget(self,action:#selector(PlusClicked),
                                   for:.touchUpInside)
            cell.btnPlus.tag = indexPath.row
            
            
            if indexClicked == indexPath.row {
                cell.viewExpand.isHidden = false
                cell.expandHeightCon.constant = 128
                cell.btnPlus.setImage(UIImage(named: "minus"), for: .normal)
            }else{
                cell.viewExpand.isHidden = true
                cell.expandHeightCon.constant = 0
                cell.btnPlus.setImage(UIImage(named: "Plus"), for: .normal)
            }
            
            
            return cell
        }
            
            
//        else{
//
//            let cell = self.tblView.dequeueReusableCell(withIdentifier: kReuseIdentifierEventTVCell) as! EventTVCell
//            cell.selectionStyle = .none
//
//            if let eData = self.eventData["event_performer"] as? Array<Dictionary<String,Any>>{
//                cell.arrEventOrganiser = eData
//
//            }
//            cell.headerLabel.text = "View Seating plan"
//            cell.configureCell()
//
//            if indexClicked == indexPath.row {
//                           cell.viewExpand.isHidden = false
//                           cell.expandHeightCon.constant = 128
//                       }else{
//                           cell.viewExpand.isHidden = true
//                           cell.expandHeightCon.constant = 0
//                       }
//                       cell.btnPlus.addTarget(self,action:#selector(PlusClicked),
//                                                       for:.touchUpInside)
//                                cell.btnPlus.tag = indexPath.row
//            return cell
//        }
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        //        if userInfo.selectedInterests.count >= 3{
        //             self.delegate.showAlert(msg: "Max 3 interest Choose!")
        //        }else{
        //           let dict = self.arrayList[indexPath.row]
        //        self.delegate.selectIndex(tabIndex: dict)
        //        }
        
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        //  self.heightAtIndexPath[indexPath] = cell.frame.size.height
        
        //     if isAnimateStop == true {
        //        if (self.arrayNotification.count - indexPath.row) == Constants.FetchThreshold && canFetchMoreResults {
        //       // isAnimateStop = false
        //          if self.delegate != nil {
        //                               self.delegate?.didPaginationForNextPage(next: selectedIndex)
        //                           }
        //        }
        //
        //            }
        
    }
    @objc func PlusClicked(sender:UIButton){
        
        indexClicked = sender.tag
        tblView.reloadData()
        
    }
    
}

