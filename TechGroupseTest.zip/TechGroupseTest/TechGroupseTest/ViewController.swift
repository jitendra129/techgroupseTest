//
//  ViewController.swift
//  TechGroupseTest
//
//  Created by Mihir on 29/06/20.
//  Copyright © 2020 Mihir. All rights reserved.
//

import UIKit
import Alamofire
import Kingfisher
import SVProgressHUD
let kDeviceSize                             = UIScreen.main.bounds
let kDeviceWidth                            = UIScreen.main.bounds.size.width
let kDeviceHeight                           = UIScreen.main.bounds.size.height


let kReuseIdentifierDateTimeDetailTVCell           = "DateTimeDetailTVCell"
let kReuseIdentifierLocationTVCell           = "LocationTVCell"
let kReuseIdentifierEventTVCell           = "EventTVCell"
let kReuseIdentifierEventOrganiserCVCell           = "EventOrganiserCVCell"
let kReuseIdentifierHomeCVCell           = "HomeTableCell"
class ViewController: UIViewController {
    var listController : HomeListController!
          @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var headerView: UIView!
        @IBOutlet weak var footerView: UIView!
     @IBOutlet weak var eventImage: UIImageView!
      @IBOutlet weak var eventTitle: UILabel!
      @IBOutlet weak var eventDetail: UILabel!
    var eventData = Dictionary<String,Any>()
    override func viewDidLoad() {
 

        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
         self.tblView.tableHeaderView = headerView
         self.listController = HomeListController(delegate: self, tblView:  self.tblView)
                self.tblView.delegate = self.listController
                self.tblView.dataSource = self.listController
        self.tblView.isHidden = true
        footerView.isHidden = true
       GetEvents()
        // Do any additional setup after loading the view.
    }
    
    func GetEvents(){
        

        SVProgressHUD.show()
        let  todosEndpoint = "http://saudicalendar.com/api/user/getEventDetail?latitude=28.1245&longitude=78.1245&user_id=0&event_id=12"
        
    
        Alamofire.request(URL(string: todosEndpoint)!, method: .get, parameters: nil, encoding: JSONEncoding.default,headers: nil)
            .responseJSON { response in
                switch response.result {
                case .success:
                
                    
                    if response.response?.statusCode == 200 {
                         if let result = response.result.value{
                     let dictDetails = result as! Dictionary<String, Any>
                    self.eventData  = dictDetails["data"] as! Dictionary<String, Any>
                        }
                        print( self.eventData)
                        let arrImage = self.eventData["ev_image"] as! Array<Dictionary<String, Any>>
                        let urlStoreImage = URL(string: arrImage[0]["image"] as! String)
                        self.eventImage.kf.setImage(with: urlStoreImage, placeholder: nil)
                        if let eName = self.eventData["ev_name"] as? String{
                        self.eventTitle.text = eName
                        }
                        if let eTitle = self.eventData["ev_title"] as? String{
                        self.eventDetail.text = eTitle
                        }
                        self.listController.refreshList(eventData: self.eventData)
                         SVProgressHUD.dismiss()
                         self.tblView.isHidden = false
                        self.footerView.isHidden = false
                    }
                    
                    
                    
                    
                case .failure(let error):
                     SVProgressHUD.dismiss()
                    print(error)
                    
                }
                
                
                
                
        }
    }
}

extension ViewController : HomeListControllerDelegate{
    func callNextPage(pageId: Int) {
      
        
        

       
    }
    
    
}

class GlobalViewWCR:UIView{
    
    required public init?(coder aDecoder: NSCoder) {
        
        super.init(coder: aDecoder)
        //  self.layer.cornerRadius = 15
        let cornerRadius: CGFloat = 0
        
        let shadowOffsetWidth: Int = 0
        let shadowOffsetHeight: Int = 0
        let shadowColor: UIColor? = UIColor.black
        let shadowOpacity: Float = 0.0
        
        layer.cornerRadius = cornerRadius
        let shadowPath = UIBezierPath(roundedRect: bounds, cornerRadius: cornerRadius)
        
        layer.masksToBounds = false
        layer.shadowColor = shadowColor?.cgColor
        layer.shadowOffset = CGSize(width: shadowOffsetWidth, height: shadowOffsetHeight);
        layer.shadowOpacity = shadowOpacity
        layer.shadowPath = shadowPath.cgPath
    }
}


@IBDesignable class GlobalView:UIView{
    
    @IBInspectable var cornerRadius: CGFloat = 5
    @IBInspectable var shadowOffsetWidth: Int = 0
    @IBInspectable var shadowOffsetHeight: Int = 2
    @IBInspectable var shadowColor: UIColor? = UIColor.gray
    @IBInspectable var shadowOpacity: Float = 0.2
    
    override func layoutSubviews() {
        
        //layer.cornerRadius = cornerRadius
        let shadowPath = UIBezierPath(roundedRect: bounds, cornerRadius: cornerRadius)
        
        layer.masksToBounds = false
        layer.shadowColor = shadowColor?.cgColor
        layer.shadowOffset = CGSize(width: shadowOffsetWidth, height: shadowOffsetHeight);
        layer.shadowOpacity = shadowOpacity
        layer.shadowPath = shadowPath.cgPath
        
    }
}
@IBDesignable class GlobalProfileImage: UIImageView {
    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        self.layer.borderWidth = 1
        self.backgroundColor = UIColor.white
        self.layer.borderColor = UIColor.black.cgColor
        self.layer.cornerRadius =  self.layer.frame.size.width / 2
    }
    
   
    @IBInspectable var borderWidth: CGFloat {
        set {
            layer.borderWidth = newValue
        }
        get {
            return layer.borderWidth
        }
    }
    @IBInspectable var borderColor: UIColor? {
        set {
            guard let uiColor = newValue else { return }
            layer.borderColor = uiColor.cgColor
        }
        get {
            guard let color = layer.borderColor else { return nil }
            return UIColor(cgColor: color)
        }
    }
    @IBInspectable var imageBGColor: UIColor? {
        set {
            guard let uiColor = newValue else { return }
            layer.backgroundColor = uiColor.cgColor
        }
        get {
            guard let color = layer.backgroundColor else { return nil }
            return UIColor(cgColor: color)
        }
    }
}
